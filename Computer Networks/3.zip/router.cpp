#include <iostream>
#include <fstream>
#include <map>
#include <string>
#include <vector>
#include <set>
#include <sstream>

#include <arpa/inet.h>
#include <sys/socket.h>
#include <string.h>
#include <unistd.h>

#define INF 0xffff
using namespace std;


class IPAddress{
public:
	unsigned char ip[4];

	void setIP(string x){
		int cnt = 0;
		unsigned char val=0;

		for(int i = 0; i < x.size(); i++){
			if(x[i]=='.'){
				ip[cnt++] = val;
				val = 0;
			}
			else{
				val = val*10;
				val += x[i]-'0';
			}
		}
		ip[3]= val;
	}


	void setIP(IPAddress x){
		for(int i = 0; i < 4; i++) ip[i]=x.ip[i];
	}

	IPAddress(string x){
		setIP(x);
	}
	IPAddress(){

	}
	IPAddress(string x, int offset){
		for(int i=offset; i < offset+4; i++){
			ip[i-offset]=x[i];
		}
	}
	bool equals(IPAddress & another){
		for(int i = 0; i < 4; i++){
			if(ip[i]!=another.ip[i]) return false;
		}
		return true;
	}

	void printIP(){
		for(int i = 0; i < 4; i++){
			cout << (int)ip[i] << ". "[i==3];
		}
	}	

	void setUnknown(){
		for(int i=0; i < 4; i++){
			ip[i]= 1;
		}
	}
	bool isUnknown(){
		for(int i = 0; i < 4; i++){
			if((int)ip[i]!=1) return false;
		}
		return true;
	}
	bool operator<(const IPAddress &another) const{
		for(int i = 0; i < 4; i++){
			if(this->ip[i] < another.ip[i]) return true;
		}
		return false;
	}

	string toString(){
		stringstream ss;
		for(int i = 0; i < 4; i++){
			ss << (int)ip[i] <<  ". "[i==3];
		}
		//cout << s << endl;
		string s;
		ss >> s;
		return s;
	}
};
/*******************global****************/
IPAddress self;
/***************************************/
class Link{
public:
	IPAddress ip;
	int cost;

	Link(string x, int c){
		ip.setIP(x);
		cost = c;
	}
	Link(IPAddress x, int c){
		ip.setIP(x);
		cost = c;
	}
};


/********************************global***********************/
vector < Link > adj;
vector <IPAddress> hosts;
map <IPAddress, bool> exists;
map <IPAddress, int> neighbor;
/************************************************************/

class RoutingTable{
	class RoutingTableEntry{
	public:	
		IPAddress destination;
		IPAddress next_hop;
		int cost;
		RoutingTableEntry(){

		}
		RoutingTableEntry(IPAddress a, IPAddress b, int c){
			destination= a;
			next_hop = b;
			cost = c;
		}
	};

	vector <RoutingTableEntry> rt;

	public:
		void buildRoutingTable(){
		//cout << hosts.size() << endl;
		for(int i = 0; i < hosts.size(); i++){
			if(hosts[i].equals(self)){
				IPAddress unknown;
				unknown.setUnknown();
				RoutingTableEntry entry(hosts[i], unknown, 0);
				rt.push_back(entry);				
			}
			else if(neighbor[hosts[i]]!=INF) {
				RoutingTableEntry entry(hosts[i], hosts[i], neighbor[hosts[i]]);
				rt.push_back(entry);
			}
			else{
				IPAddress unknown;
				unknown.setUnknown();
				RoutingTableEntry entry(hosts[i], unknown, INF);
				rt.push_back(entry);
			}

		}
	}


	void printRoutingTable(){
		cout << "\n destination \t next hop \t cost \n";
		cout << "------------- \t --------- \t ---- \n";

		for(int i = 0; i < rt.size(); i++){
			rt[i].destination.printIP();
			cout << " \t ";
			if(rt[i].next_hop.isUnknown()) {
				cout << "   -   \t ";
			}
			else{
				rt[i].next_hop.printIP();
				cout << " \t ";
			}
			if(rt[i].cost==INF)cout << "inf" << endl;
			else cout << rt[i].cost << endl;
		}
		cout << "---------------------------------" << endl;
	}
	void upgradeRoutingTable(){
		rt.clear();
		for(int i = 0; i < hosts.size(); i++){
			if(hosts[i].equals(self)){
				IPAddress unknown;
				unknown.setUnknown();
				RoutingTableEntry entry(hosts[i], unknown, 0);
				rt.push_back(entry);				
			}
			else if(neighbor[hosts[i]]!=INF) {
				RoutingTableEntry entry(hosts[i], hosts[i], neighbor[hosts[i]]);
				rt.push_back(entry);
			}
			else{
				IPAddress unknown;
				unknown.setUnknown();
				RoutingTableEntry entry(hosts[i], unknown, INF);
				rt.push_back(entry);
			}
		}
	}
	void sendRoutingTable(){
		cout << "sending routing table..." << endl;
		for(int i = 0; i < adj.size(); i++){
			//adj[i].ip.toString();
			
			char tosend[100];
			strcpy(tosend,adj[i].ip.toString().c_str());
			char sender[100];
			strcpy(sender, self.toString().c_str());

			cout << "sender: " << sender <<endl;
			cout << "receiver:"  << tosend << endl;
			int sockfd;
			int bind_flag;
			int sent_bytes;
			char buffer[1024];
			struct sockaddr_in server_address;
			struct sockaddr_in client_address;


			

			server_address.sin_family = AF_INET;
			server_address.sin_port = htons(4747);
			//server_address.sin_addr.s_addr = inet_addr("192.168.10.100");
			inet_pton(AF_INET,tosend,&server_address.sin_addr);	

			client_address.sin_family = AF_INET;
			client_address.sin_port = htons(4747);
			//client_address.sin_addr.s_addr = inet_addr(argv[1]);
			inet_pton(AF_INET,sender,&client_address.sin_addr);

			sockfd = socket(AF_INET, SOCK_DGRAM, 0);
			bind_flag = bind(sockfd, (struct sockaddr*) &client_address, sizeof(sockaddr_in));
			if(bind_flag==0)printf("successful bind\n");


			strcpy(buffer,"rtab");

			string s = "";
			for(int k = 0; k < 4; k++){
				s+=self.ip[k];
			}
			strcat(buffer,s.c_str());
			// cout << "buffer size:" << strlen(buffer) << endl;

			for(int j = 0; j < rt.size(); j++){
				s = "";
				for(int k = 0; k < 4; k++){
					s+=rt[j].destination.ip[k];
				}
				strcat(buffer,s.c_str());
				// cout << "buffer size:" << strlen(buffer) << endl;

				s = "";
				for(int k = 0; k < 4; k++){
					s+=rt[j].next_hop.ip[k];
				}

				strcat(buffer, s.c_str());
				unsigned int cost = rt[j].cost;
				unsigned char cost1 = cost/256+1;
				unsigned char cost0 = cost%256+1;

				s = "";
				s+=cost0;
				s+=cost1;
				strcat(buffer,s.c_str());

				// strcpy(buffer, "\0");
				// cout << "buffer size:" << strlen(buffer) << endl;

			}

			cout << "sent size:" << strlen(buffer) << endl;
			sent_bytes=sendto(sockfd, buffer, 1024, 0, (struct sockaddr*) &server_address, sizeof(sockaddr_in));
			



			close(sockfd);

		}		
	}



	void sendMessage(string buf, string msg, IPAddress dest){
		if(dest.equals(self)){
			cout << msg << endl;
			cout << " packet reached destination.\n";
		}
		else{
			IPAddress next_hop;
			for(int i = 0; i < rt.size(); i++){
				if(rt[i].destination.equals(dest)){
					next_hop= rt[i].next_hop;

					break;
				}
			}
			cout << msg << "packet forwarded to ";
			next_hop.printIP(); 
			cout << endl;

			/*found the next hop*/
			/*******now sending**************/

			int sockfd;
			int bind_flag;
			int sent_bytes;
			char buffer[1024];
			struct sockaddr_in server_address;
			struct sockaddr_in client_address;


			char sender[100];
			strcpy(sender, self.toString().c_str()) ;
			char tosend[100];
			strcpy(tosend, next_hop.toString().c_str());
			strcpy(buffer, buf.c_str());



			server_address.sin_family = AF_INET;
			server_address.sin_port = htons(4747);
			//server_address.sin_addr.s_addr = inet_addr("192.168.10.100");
			inet_pton(AF_INET,sender,&server_address.sin_addr);	

			client_address.sin_family = AF_INET;
			client_address.sin_port = htons(4747);
			//client_address.sin_addr.s_addr = inet_addr(argv[1]);
			inet_pton(AF_INET,tosend,&client_address.sin_addr);

			sockfd = socket(AF_INET, SOCK_DGRAM, 0);
			bind_flag = bind(sockfd, (struct sockaddr*) &client_address, sizeof(sockaddr_in));
			if(bind_flag==0)printf("successful bind\n");


			
			sent_bytes=sendto(sockfd, buffer, 1024, 0, (struct sockaddr*) &server_address, sizeof(sockaddr_in));
			


			close(sockfd);



		}
	}
};

/******************global *****************/
RoutingTable table;
/*****************************************/

void upgradeCost(IPAddress ip, int cost){
	for(int i = 0; i < adj.size(); i++){
		if(adj[i].ip.equals(ip)){
			if(neighbor[ip]>=adj[i].cost) neighbor[ip] = cost;
			adj[i].cost = cost;
			break;
		}
	}
	
	table.upgradeRoutingTable();
}
map <IPAddress,bool> alive;

void listen(char * ip){
	int sockfd; 
	int bind_flag;
	int bytes_received;
	socklen_t addrlen;
	char buffer[1024];
	struct sockaddr_in server_address;
	struct sockaddr_in client_address;

	server_address.sin_family = AF_INET;
	server_address.sin_port = htons(4747);
	inet_pton(AF_INET,ip, &server_address.sin_addr);
	
	sockfd = socket(AF_INET, SOCK_DGRAM, 0);
	
	bind_flag = bind(sockfd, (struct sockaddr*) &server_address, sizeof(sockaddr_in));
	
	if(bind_flag==0) printf("successful bind\n");

	while(true){
		bytes_received = recvfrom(sockfd, buffer, 1024, 0, (struct sockaddr*) &client_address, &addrlen);
		
		// printf("[%s:%hu]: %s\n", inet_ntoa(client_address.sin_addr), ntohs(client_address.sin_port), buffer);
		
		//printf("%hu\n",client_address.sin_port);
		//printf("%u\n",client_address.sin_addr.s_addr);

		string s(buffer);

		// cout << s << endl;

		if(s.compare(0,3,"clk")==0){
			table.sendRoutingTable();
			cout << "this is clock" << endl;
		}
		else if(s.compare(0,4,"cost")==0){
			cout << "this is cost" << endl;
			IPAddress ip1(s,4);
			IPAddress ip2(s,8);
			string costname(s,12,2);

			unsigned char cost0 = costname[0];
			unsigned char cost1 = costname[1];
			unsigned int cost = cost0+cost1*256;
			ip1.printIP();
			ip2.printIP();
			//cout << (int) cost0 <<" " << (int)cost1<< endl;
			//cout << cost <<endl;
			if(ip1.equals(self)){
				upgradeCost(ip2,cost);
			}
			else{
				upgradeCost(ip1,cost);
			}
		}
		else if(s.compare(0,4,"send")==0){
			cout << "this is send" << endl;
			IPAddress ip1(s,4);
			IPAddress dest(s,8);
			string msglen(s,12,2);

			unsigned char len0 = msglen[0];
			unsigned char len1 = msglen[1];
			unsigned int len = len0+len1*256;

			string msg(s,14,len);
			//ip1.printIP();
			dest.printIP();
			table.sendMessage(s,msg,dest);	
		}
		else if(s.compare(0,4, "show")==0){
			table.printRoutingTable();
		}
		else if(s.compare(0,4,"rtab")==0){
			cout << "receiving routing table..." << endl;
			cout << "size: " << s.size() << endl;
			IPAddress sender(s,4);
			cout << "from sender:";
			sender.printIP();
			cout << endl;

			for(int i = 8; i < s.size(); i+=10){
				IPAddress dest(s,i);
				IPAddress next_hop(s,i+4);
				string costname(s,i+8,2);
				unsigned char cost0 = costname[0]-1;
				unsigned char cost1 = costname[1]-1;
				int cost = cost0+cost1*256;
				cout << "dest:";
				dest.printIP();
				cout << "next_hop:";
				next_hop.printIP();
				cout << cost << endl;

				if(neighbor[dest] > cost+neighbor[sender]){
					neighbor[dest] = cost+neighbor[sender];
					table.upgradeRoutingTable();
				}				
			}

		}
		else if(strcmp(buffer,"shutdown")==0)break;		

	}

	close(sockfd);
}




int main(int argc, char** argv){

	if(argc < 3){
		cout << "use the following arguments: <ip address> <topology-file>\n";
		return 0;
	}


	ifstream file(argv[2]);

	if(!file.is_open()){
		cout << "invalid file" << endl;
		return 0;
	}

	self.setIP(argv[1]);
	// printIP(self);

	string ipname1, ipname2;
	IPAddress ip1, ip2;
	int cost;	
	while(file>> ipname1 >> ipname2 >> cost){

		ip1.setIP(ipname1);
		ip2.setIP(ipname2);

		//printIP(ip1);
		//printIP(ip2);
		if(self.equals(ip1)){
			Link a(ip2,cost);
			adj.push_back(a);
			neighbor[ip2]=cost;

		}
		else if(self.equals(ip2)){
			Link a(ip1,cost);
			adj.push_back(a);
			neighbor[ip1]=cost;

		}
		else{
			if(!exists[ip1])neighbor[ip1]=INF;
			if(!exists[ip2])neighbor[ip2]=INF;

		}


		if(!exists[ip1]){
			hosts.push_back(ip1);
			exists[ip1] = true;
		}
		if(!exists[ip2]){
			hosts.push_back(ip2);
			exists[ip2] = true;
		}
	}


	
	table.buildRoutingTable();
	table.printRoutingTable();

	listen(argv[1]);
	return 0;
}
