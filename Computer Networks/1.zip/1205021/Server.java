
import java.io.*;
import java.net.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;


public class Server
{
	public static int workerThreadCount = 0;
	public static List <String> filesShared= new ArrayList<String>();
	
	public static void main(String args[])
	{
		int id = 1;
		
		try
		{
			ServerSocket ss = new ServerSocket(5555);
			System.out.println("Server has been started successfully.");
			
			while(true)
			{
				Socket s = ss.accept();		//TCP Connection
				WorkerThread wt = new WorkerThread(s, id);
				Thread t = new Thread(wt);
				t.start();
				workerThreadCount++;
				System.out.println("Client [" + id + "] is now connected. No. of worker threads = " + workerThreadCount);
				id++;
			}
		}
		catch(Exception e)
		{
			System.err.println("Problem in ServerSocket operation. Exiting main.");
		}
	}
}

class WorkerThread implements Runnable
{
	private Socket socket;
	private InputStream is;
	private OutputStream os;
	
	private int id = 0;
	
	public WorkerThread(Socket s, int id)
	{
		this.socket = s;
		
		try
		{
			this.is = this.socket.getInputStream();
			this.os = this.socket.getOutputStream();
		}
		catch(Exception e)
		{
			System.err.println("Sorry. Cannot manage client [" + id + "] properly.\n\n");
		}
		
		this.id = id;
	}
	
	public void run()
	{
		BufferedReader br = new BufferedReader(new InputStreamReader(this.is));
		PrintWriter pr = new PrintWriter(this.os);
		
		pr.println("Your id is: " + this.id);
		pr.flush();
		
		String str;
		
		boolean success=false;
		String username=null,password=null;
		
		
		//////////////////////////////////////////////////////////
		//////////APPROVAL
		////////////////////////////////////////////////////////
		while(!success){
			try
			{
				if( (username = br.readLine()) != null )
				{
					if((password = br.readLine())!=null){
						String alloweduser, allowedpass;
						
						System.out.println(username);
						System.out.println(password);
						
						try(BufferedReader brr = new BufferedReader(new FileReader("users.txt"))) {
						    for(String line; (line = brr.readLine()) != null; ) {
						        // process the line.
						    	System.out.println(line);
				
						    	int end=0;
						    	for(int i=0;i<line.length();i++){
						    		
						    		if(line.charAt(i)==' '){
						    			break;
						    		}
						    		end++;
						    	}
						    	
						    	alloweduser=line.substring(0,end);
						    	allowedpass=line.substring(end+1);
						    	System.out.println(alloweduser);
						    	System.out.println(allowedpass);
						    	
						    	if(username.equals(alloweduser)&& password.equals(allowedpass)){
						    		success=true;
						    		break;
						    	}

						    }
						    // line is not visible here.
						} catch (FileNotFoundException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						} catch (IOException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}						
					}
				}
			}catch(Exception e){
				
			}
			if(success){
				
				pr.println("Successfull!");
	    		pr.flush();
			}
	    	else{
	    		System.out.println("Unsuccessfull! Try again!\n\n\n\n");
	    		pr.println("Unsuccessfull! Try again!");
	    		pr.flush();
	    	}
			
		}
		System.out.println("Session Started for "+id+"\n\n\n\n\n");
		pr.println("Approved!!!!!");
		pr.flush();
		
		
		///////////////////////////////////////////////////////////////////////////////
		//////////GET FILES LIST SHARED BY THE USER
		/////////////////////////////////////////////////////////////////////////////
		
		//NIJER LIST E FILE THAKE NOTUN KORE JOG KORBE NA
		
		String  nm=null;
		System.out.println("GETTING ALL FILE INFO");
		
		while(true)
		{
			try
			{
				if( (nm = br.readLine()) != null ){					
					if(nm.equals("EOF"))break;					
					System.out.println(nm);
					
					boolean flag=true;
					for(int i=0;i<Server.filesShared.size();i++){
						String s=Server.filesShared.get(i);
						if(s.substring(0,nm.length()).equals(nm)){
							System.out.println(nm+"already exists");
							s =s+" "+ username;
							Server.filesShared.set(i,s);
							flag=false;
							break;
						}
					}
					nm= nm+" "+username;
					if(flag){
						Server.filesShared.add(nm);
					}
					
				}
			}catch(Exception e){
				
			}
		}
		////////////////////////////////////////////////////////////////////
		System.out.println("DONE GETTING ALL FILES");
		
		
		try {
			PrintWriter output = new PrintWriter("fileList.txt");
			for(String s:Server.filesShared){
				System.out.println(s);
				output.println(s);
			}
			output.close();
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		System.out.println("DONE WRITING IN THE LOG");
		
		
		//////////////////////////////////////////////////////////////////////
		//////////////////////////////////////////////////////////////////////
		while(true)
		{
			try
			{
				if( (str = br.readLine()) != null )
				{
					if(str.equals("EXIT"))
					{
						System.out.println("[" + id + "] says: BYE. Worker thread will terminate now.\n\n\n");
						break; // terminate the loop; it will terminate the thread also
					}
					else if(str.equals("LIST")){
//						pr.println(Server.filesShared.size());
//						pr.flush();
						for(String s:Server.filesShared){
							System.out.println(s);
							pr.println(s);
							pr.flush();
						}
						System.out.println("\n\n");
						
						pr.println("EOF");
						pr.flush();
					}
					else if(str.substring(0,2).equals("DL"))
					{
						
						System.out.println("got it!\n\n\n");
						
						String fname=str.substring(3,str.length());
						System.out.println(fname);
						try
						{
							File file = new File(fname);
							FileInputStream fis = new FileInputStream(file);
							BufferedInputStream bis = new BufferedInputStream(fis);
							OutputStream os = socket.getOutputStream();
							byte[] contents;
							long fileLength = file.length();
							pr.println(String.valueOf(fileLength));		//These two lines are used
							pr.flush();									//to send the file size in bytes.
							
							long current = 0;
							 
							long start = System.nanoTime();
							while(current!=fileLength){ 
								int size = 10000;
								if(fileLength - current >= size)
									current += size;    
								else{ 
									size = (int)(fileLength - current); 
									current = fileLength;
								} 
								contents = new byte[size]; 
								bis.read(contents, 0, size); 
								os.write(contents);
								//System.out.println("Sending file ... "+(current*100)/fileLength+"% complete!");
							}   
							os.flush(); 
							System.out.println("File sent successfully!");
						}
						catch(Exception e)
						{
							System.err.println("Could not transfer file.");
						}
						pr.println("Downloaded.");
						pr.flush();

					}
					else
					{
						System.out.println("[" + id + "] says: " + str);
						pr.println("Got it. You sent \"" + str + "\"");
						pr.flush();
					}
				}
				else
				{
					System.out.println("[" + id + "] terminated connection. Worker thread will terminate now.");
					break;
				}
			}
			catch(Exception e)
			{
				System.err.println("Problem in communicating with the client [" + id + "]. Terminating worker thread.");
				break;
			}
		}
		
		try
		{
			this.is.close();
			this.os.close();
			this.socket.close();
		}
		catch(Exception e)
		{
		
		}
		
		
		/////////////////////////////////////////////////////////////////
		///////////////////////EXIT
		//////////////////////////////////////////////////////////////////
		
		Server.workerThreadCount--;
		System.out.println("Client [" + id + "] is now terminating. No. of worker threads = " 
				+ Server.workerThreadCount);
		
		
		for(int i=0; i< Server.filesShared.size();i++){
			String s=Server.filesShared.get(i);
			while(s.contains(username)){
				System.out.println("True");
				int idx=s.indexOf(username);
				s= s.substring(0,idx)+s.substring(idx+username.length(),s.length());
			}
//			int cnt=0;
//			for(int j=0;i<s.length();i++){
//				if(s.charAt(j)==' ') cnt++;
//			}
//			if(cnt>1){
				Server.filesShared.set(i, s);
				System.out.println(Server.filesShared.get(i));
//			}
//			else{
////				Server.filesShared.set(i,"");
//			}
		}
		
		
		////////////////////////////////////////////////////////////////////////////
		try {
			PrintWriter output = new PrintWriter("fileList.txt");
			for(String s:Server.filesShared){
				System.out.println(s);
				output.println(s);
			}
			output.close();
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		System.out.println("DONE WRITING IN THE LOG");		
		
		
	}
}
