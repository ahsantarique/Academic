import java.io.*;
import java.net.*;
import java.util.*;

public class Client
{
	private static Socket s = null;
	private static BufferedReader br = null;
	private static PrintWriter pr = null;
	
	public static void main(String args[])
	{	
		Scanner reader=new Scanner(System.in);
		String username=null,password=null;
		
		boolean success=false;
		
	
		//////////////////////////////////////////////////////////////////////////////////////////////////////
		/////////////////////ESTABLISH CONNECTION
		////////////////////////////////////////////////////////////////////////////////////////////////////
		try
		{
			s = new Socket("localhost", 5555);
			
			br = new BufferedReader(new InputStreamReader(s.getInputStream()));
			pr = new PrintWriter(s.getOutputStream());
		}
		catch(Exception e)
		{
			System.err.println("Problem in connecting with the server. Exiting main.");
			System.exit(1);
		}
		
		Scanner input = new Scanner(System.in);
		
		
		String strSend = null, strRecv = null;
		
		while(true){
			try {
				if((strRecv=br.readLine())!=null){
					System.out.println(strRecv);
					break;
				}
				
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}		
		
		//////////////////////////////////////////////////////////////////////////////////////////////////////
		//////////////////////LOGIN ATTEMPT
		///////////////////////////////////////////////////////////////////////////////////////////////////
		
		while(!success){
			
			System.out.println("Enter your Username:");
			username=reader.nextLine();
			System.out.println("username: "+username);
	
			System.out.println("Enter your Password:");
			password=reader.nextLine();
			System.out.println("pass: "+password);
			
			pr.println(username);
			pr.flush();			
			
			pr.println(password);
			pr.flush();

			System.out.println("Change occured");
			while(true){
				try {
					if((strRecv=br.readLine())!=null){
						System.out.println(strRecv);
						if(strRecv.equals("Successfull!")){
							success=true;
						}
						break;
					}
					
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
//			System.out.println("hit end");
		}
		///////////////////////////////////////////////////////////////////////
		////////////// VERIFIED
		/////////////////////////////////////////////////////////////////////////

		System.out.println("Okay, starting new session as "+ username+"\n\n\n");

		
		try
		{
			strRecv = br.readLine();
			if(strRecv != null)
			{
				System.out.println("Server says: " + strRecv);
			}
			else
			{
				System.err.println("Error in reading from the socket. Exiting main.");
				cleanUp();
				System.exit(0);	
			}
		}
		catch(Exception e)
		{
			System.err.println("Error in reading from the socket. Exiting main.");
			cleanUp();
			System.exit(0);
		}		
		
		////////////////////////////////////////////////////////////////////////////////////
		///////FIRST SEND LIST OF FILES OWNED BY MYSELF
		////////////////////////////////////////////////////////////////////////////////////
		
		System.out.println("\n In my Shared Folder:\n");
		File folder = new File(""+username);
		File[] listOfFiles = folder.listFiles();

	    for (int i = 0; i < listOfFiles.length; i++) {
	      if (listOfFiles[i].isFile()) {
	        System.out.println("File: " + listOfFiles[i].getName()+ "         Size: "+ listOfFiles[i].length());
	        
	        String ss=listOfFiles[i].getName()+" "+listOfFiles[i].length();
	        System.out.println(ss);
	        pr.println(ss);
	        pr.flush();
	        
//	        pr.println(listOfFiles[i].length());
//	        pr.flush();
	        //
	        
	      } else if (listOfFiles[i].isDirectory()) {
	        System.out.println("Directory " + listOfFiles[i].getName());
	      }
	    }
	    System.out.println("EOF");
	    pr.println("EOF");
		pr.flush();
		///////////////////////////////////////////////////////////////////////////////////
		////////////////SEND COMMANDS
		//////////////////////////////////////////////////////////////////////////////////
		



		System.out.println();

		System.out.println("******************MENU****************************");
		System.out.println("1.TO SEE LIST OF FILE TYPE \"LIST\"");
		System.out.println("2.TO DOWNLOAD A FILE TYPE COMMAND \"DL FILENAME\"");
		System.out.println("3.TO EXIT TYPE \"EXIT\"");
		System.out.println("**************************************************");
		
		System.out.println();
		
		
		while(true)
		{
			System.out.print("Enter a Command: ");
			try
			{
				strSend = input.nextLine();
			}
			catch(Exception e)
			{
				continue;
			}
			
			pr.println(strSend);
			pr.flush();
			if(strSend.equals("EXIT"))
			{
				System.out.println("Client wishes to terminate the connection. Exiting main.");
				break;
			}
			else if(strSend.equals("LIST")){
				System.out.println("\n*********SHOWING LIST*************\n");
				String sss=null;
				
				while(true){
//					System.out.println("22");
					try {
						if((sss=br.readLine())!=null){
							if(sss.equals("EOF")) break;
	
							System.out.println(sss);
						}
						
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			}
			else if(strSend.substring(0,2).equals("DL"))
			{
				String fname=strSend.substring(3,strSend.length());
				System.out.println(fname);
				try
				{
					strRecv = br.readLine();					//These two lines are used to determine
					int filesize=Integer.parseInt(strRecv);		//the size of the receiving file
					byte[] contents = new byte[10000];
        
					FileOutputStream fos = new FileOutputStream(fname);
					BufferedOutputStream bos = new BufferedOutputStream(fos);
					InputStream is = s.getInputStream();
				
					int bytesRead = 0; 
					int total=0;			//how many bytes read
					
					while(total!=filesize)	//loop is continued until received byte=totalfilesize
					{
						bytesRead=is.read(contents);
						total+=bytesRead;
						bos.write(contents, 0, bytesRead); 
					}
					bos.flush(); 
				}
				catch(Exception e)
				{
					System.err.println("Could not transfer file.");
				}
								
			}
//			try
//			{
//				strRecv = br.readLine();
//				if(strRecv != null)
//				{
//					System.out.println("Server says: " + strRecv);
//				}
//				else
//				{
//					System.err.println("Error in reading from the socket. Exiting main.");
//					break;
//				}
//			}
//			catch(Exception e)
//			{
//				System.err.println("Error in reading from the socket. Exiting main.");
//				break;
//			}
			
		}
		
		cleanUp();
	}
	
	private static void cleanUp()
	{
		try
		{
			br.close();
			pr.close();
			s.close();
		}
		catch(Exception e)
		{
		
		}
	}
}
