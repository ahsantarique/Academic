
struct simple {
	char *ch;
	double d;
	char c;
};
