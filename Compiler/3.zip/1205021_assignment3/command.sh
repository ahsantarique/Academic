bison -d -y 1205021.y
echo "1"
g++ -w -c -o yaccDemo.o y.tab.c
echo "2"
flex 1205021.lex
echo "3"
g++ -fpermissive -w -c -o lexDemo.o lex.yy.c
echo "4"
g++ -o myCompiler lexDemo.o yaccDemo.o -lfl -ly
echo "5"
./myCompiler
echo "6"
