#include <string>
using namespace std;

class simple{
	public:
	string type;
	int width;
	simple(string t, int w){
		type = t;
		width = w;
	}
};

