<html>
<head>
<title>Insert Page</title>
</head>
<body>
</body>
<form action="insertData.php" method="post">
	<p>Please insert data below</p>
	<p>
		Name:</br>
		<input type="text" name="Name" size="40" maxlength="40" value="">
	</p>
	<p>
		Age:</br>
		<input type="text" name="Age" size="40" maxlength="40" value="">
	</p>
	<p>
		Salary:</br>
		<input type="text" name="Salary" size="40" maxlength="40" value="">
	</p>
	<p>
		<input type="submit" name="submit" value="Insert Data">
	</p>
</form>

</html>