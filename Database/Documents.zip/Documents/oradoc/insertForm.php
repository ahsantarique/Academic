<form action="insertData.php" method="post">
    <p>Add a Location to the LOCATIONS table.</p>
    <p>
      Name:<br />
      <input type="text" name="Name" size="40" maxlength="40" value="" />
    </p> 
    <p>
      Age:<br />
      <input type="text" name="Age" size="20" maxlength="20" value="" /> 
    </p> 
    <p>
      Salary:<br />
      <input type="text" name="Salary" size="20" maxlength="20" value="" />
    </p>

    <p>
      <input type="submit" name="submit" value="Submit!" /> 
    </p>
</form>

