<html>
<head>
</head>
<body>
<table>
<tr>
<td>
    <p>Welcome to Sample page!<br />
		What do you want to do?
	</p>
</td>
</tr>
<tr>
<td>
<form action="insertForm.php" method="post">
    <p>
      <input type="submit" name="submit" value="Insert" /> 
    </p>
</form>
</td>
<td>

<form action="showData.php" method="post">
    <p>
      <input type="submit" name="submit" value="Show" /> 
    </p>
</form>
</td>
</tr>
</table>
</body>
</html>

