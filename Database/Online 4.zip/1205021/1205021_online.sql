--1
set serveroutput on


create or replace function max_dept(c_id in varchar2)
return number
is
CURSOR C1 IS 
select  count(*) as cc, tab1.department_id as dd from (SELECT D.DEPARTMENT_ID, D.DEPARTMENT_NAME FROM DEPARTMENTS D JOIN LOCATIONS L ON D.LOCATION_ID = L.LOCATION_ID WHERE L.COUNTRY_ID = c_id) tab1 join employees e
on (e.department_id = tab1.department_ID) group by tab1.department_id ;
VDEPT C1%ROWTYPE;

mx number := -1;
mxdpt number;


begin


if not(c1%isopen) then open c1;
end if;

IF(C1%NOTFOUND) THEN DBMS_OUTPUT.PUT_LINE('NO DEPARTMENTS IN THAT COUNTRY!');
end if;

loop
  exit when c1%notfound;
  fetch c1 into vdept;
  
  if(vdept.cc > mx) then
    mx := vdept.cc;
    mxdpt := vdept.dd;
  end if;
end loop;

close c1;

dbms_output.put_line('the dept with maximum employees: ' || mxdpt || ' which has ' || mx || ' number of employees');

return (mxdpt);

end;
/
/*
select*from departments;
select * from employees;
*/

declare
x number;

begin
x :=max_dept('US');
dbms_output.put_line(x);

end;
/



--2

set serveroutput on

create or replace procedure disp_minemp
as

type vyear is varray(10) of number; 

CURSOR C1 IS 
select  distinct tab1.jjy  as y from
(SELECT EXTRACT(YEAR FROM HIRE_DATE) as jjy, COUNT(*) cnt FROM EMPLOYEES GROUP BY EXTRACT(YEAR FROM HIRE_DATE) ) tab1 join
(SELECT EXTRACT(YEAR FROM HIRE_DATE), COUNT(*) cnt FROM EMPLOYEES GROUP BY EXTRACT(YEAR FROM HIRE_DATE) ) tab2
on  tab1.cnt =
(
select min(cc)from
( SELECT COUNT(*) cc FROM EMPLOYEES GROUP BY EXTRACT(YEAR FROM HIRE_DATE)
)
)
;


CURSOR C2 IS
SELECT LAST_NAME, EXTRACT(YEAR FROM HIRE_DATE) YY FROM EMPLOYEES;

EMPYEAR C1%ROWTYPE;
VCUR    C2%ROWTYPE;

/*
MN NUMBER := 100000;
mnyear vyear;
ind number;*/

begin
/*
IF NOT(C1%ISOPEN) THEN OPEN C1;
END IF;

mnyear := (0,0,0,0,0,0,0,0,0,0);
ind := 0;

LOOP
  EXIT WHEN (C1%NOTFOUND);
  
  FETCH C1 INTO EMPYEAR;
  
  IF(EMPYEAR.CNT < MN) THEN
    ind := 0;
    MN := EMPYEAR.CNT;
    MNYEAR(ind) := EMPYEAR.JOINYEAR;
    ind := ind + 1;
  elsif(EMPYEAR.CNT = MN) then
    MNYEAR(ind) := EMPYEAR.JOINYEAR;
    ind := ind + 1;    
  END IF;

END LOOP;

CLOSE C1;


IF NOT(C2%ISOPEN) THEN OPEN C2;
END IF;

DBMS_OUTPUT.PUT_LINE('THE FOLLOWING EMPLOYEES JOINED IN: ' || MNYEAR );
DBMS_OUTPUT.PUT_LINE('A TOTAL OF: ' || MN);


LOOP
  EXIT WHEN C2%NOTFOUND;
  FETCH C2 INTO VCUR;
  
  for ii in 1..12
  loop
    IF(VCUR.YY = MNYEAR(ii)) THEN
      DBMS_OUTPUT.PUT_LINE(VCUR.LAST_NAME);
    END IF;
  end loop;
END LOOP;
*/


open c1;
open c2;

loop
 exit when c1%notfound;
 fetch c1 into empyear;
  loop
    open c2;
    exit when c2%notfound;
    fetch c2 into vcur;
    if(vcur.yy = empyear.y) then
      dbms_output.put_line(vcur.last_name);
    end if;
  end loop;
  close c2;
end loop;

close c1;


end;
/

