%pocket algo

trainFile = textread('trainLinearlyNonSeparable.txt');
testFile= textread('testLinearlyNonSeparable.txt');

posLabel = 2;
negLabel = 1;

n = size(trainFile,2) - 1; %number of features
m = size(trainFile,1) - 1; % number of samples
label = n+2;

train= [ones(m,1) trainFile(2:end,:)];  %traindata + label
w = rand(n+1,1);    %weight column vector (n+1)x1
tempw = w;
bestw = w;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

p = 0.7;

cost = 1;
bestcost = 10000;

maxiteration = 1e4;
iteration = 0;
while(cost ~=0 && iteration < maxiteration)
    cost = 0;
    for i=1:m
        x = train(i,1:n+1);  %feature row vector 1x(n+1)
        predict = x*w;
        if(train(i, label)==posLabel && predict < 0)
            cost = cost - predict;
            tempw = tempw+p*x';
        end
        if(train(i, label)==negLabel && predict > 0)
            cost = cost + predict;
            tempw = tempw-p*x';
        end
    end
    w = tempw;          %change all at once
    
    if(cost < bestcost)
        bestcost = cost;
        bestw = w;
    end;    %keep history in pocket
    
    iteration = iteration + 1;
end

%training done
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%now testing

tpos = 0;
tneg = 0;
fpos = 0;
fneg = 0;


disp('Actual Class      Predicted Class');
disp('------------     ------------------');

for i=1:m
        x = [1 testFile(i,1:n)];
        predict = x*w;
        actual = testFile(i,n+1);
        if(predict < 0)
            fprintf('\t%d \t\t\t\t %d\n',actual, negLabel);

            if(actual==negLabel)
                tneg = tneg+1;
            else
                fneg = fneg+1;
            end;
        else
            fprintf('\t%d \t\t\t\t %d\n',actual, posLabel);
            if(actual==posLabel)
                tpos = tpos+1;
            else
                fpos = fpos+1;
            end;
        end;
end;

P = tpos + fneg;
N = tneg + fpos;
accuracy = (tpos+tneg)/(P+N);
precision = (tpos)/(tpos+fpos);
recall = (tpos)/P;

fprintf('true positive:%d\n', tpos);
fprintf('true negative:%d\n', tneg);
fprintf('false positive:%d\n', fpos);
fprintf('false negative:%d\n', fneg);

fprintf('accuracy : %.2f %% \n', accuracy*100);
fprintf('precision : %.2f %% \n', precision*100);
fprintf('recall : %.2f %% \n', recall*100);


% Find Indices of Positive and Negative Examples
if(n < 4)  
    y = testFile(:,n+1);
    pos = find(y==posLabel);
    neg = find(y == negLabel);

    % Plot Examples
    plot(testFile(pos, 1), testFile(pos, 2), 'k+','LineWidth', 2, 'MarkerSize', 7);
    hold on;
    plot(testFile(neg, 1), testFile(neg, 2), 'ko', 'MarkerFaceColor', 'y', 'MarkerSize', 7);
    
    %decision boundary
    plotpc(w(2:end,1)', w(1,1));
end