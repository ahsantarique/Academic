file= load('train.txt');

train=file(2:size(file,1),:);


m = size(train,1);
used=[];
t1= zeros(25,3);
t2=zeros(25,3);



for i=1:25
    r= uint16(round((m-0).*rand(1,1)));
    
    while( train(r,3)==2)
        disp(r);
        r= uint16(round((m-0).*rand(1,1)));
    end;
    used=[used;r];
    
    t1(i,:)=train(r,:);
end;


disp(t1);


for i=1:25
    r= int16(round((m-0).*rand(1,1)));
    while( train(r,3)==1)
        r= uint16(round((m-0).*rand(1,1)));
    end;
    used=[used;r];
    
    t2(i,:)=train(r,:);
end;


disp(t2);



%done picking train data



u11=mean(t1(:,1));
u12=mean(t1(:,2));


sigma11=std(t1(:,1));
sigma12=std(t1(:,2));


u21=mean(t2(:,1));
u22=mean(t2(:,2));


sigma21=std(t2(:,1));
sigma22=std(t2(:,2));


test= load('test.txt');



correct=0;
wrong=0;

for i=1:size(test,1)
    x1=test(i,1);
    x2=test(i,2);
    
    
   p11=1/(sqrt(2*pi)*sigma11)*exp(-(x1-u11).^2/(2*sigma11));
   p12=1/(sqrt(2*pi)*sigma12)*exp(-(x2-u12).^2/(2*sigma12));
   p21=1/(sqrt(2*pi)*sigma21)*exp(-(x1-u21).^2/(2*sigma21));
   p22=1/(sqrt(2*pi)*sigma22)*exp(-(x2-u22).^2/(2*sigma22));
   if(p11*p12 > p21*p22)
       disp(1);
       if(test(i,3)==1)
           correct = correct+1;
       else
           wrong=wrong+1;
       end;
       
   else
       disp(2);
       if(test(i,3)==2)
           correct = correct+1;
       else
           wrong=wrong+1;
       end;
   end;
    
end

disp('accuracy');
disp(correct);

