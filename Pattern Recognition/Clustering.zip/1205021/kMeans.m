function [centroids, idx] = kMeans(k, D, index)

b = randperm(max(index));
initial_centroids = [];

for i =1:k
    if(length(find(b(i)==index))>0)
        initial_centroids = [initial_centroids; D(b(i),:)];
    end
end
max_iters = 10;
[centroids, idx] = runkMeans(D(index,:), initial_centroids, max_iters);
fprintf('\nK-Means Done.\n\n');
disp(centroids);
disp(idx);
end

function idx = findClosestCentroids(X, centroids)
K = size(centroids, 1);

idx = zeros(size(X,1), 1);

m = size(X,1);
%disp(X);
%disp(centroids);

for i=1:m
    min = 1e18;
    for j=1:K
        diffmat = sum((X(i,:)-centroids(j,:)).^2);
        dif = sum(diffmat);
        if(dif<min)
            min = dif;
            idx(i) = j;
        end
    end
end

%disp(diffmat);

end

function [centroids, idx] = runkMeans(X, initial_centroids, ...
                                      max_iters)
[m n] = size(X);
K = size(initial_centroids, 1);
centroids = initial_centroids;
idx = zeros(m, 1);

% Run K-Means
for i=1:max_iters
    
    % For each example in X, assign it to the closest centroid
    idx = findClosestCentroids(X, centroids);
    % Given the memberships, compute new centroids
    centroids = computeCentroids(X, idx, K);
end
end


function centroids = computeCentroids(X, idx, K)
%COMPUTECENTROIDS returns the new centroids by computing the means of the 
%data points assigned to each centroid.
%   centroids = COMPUTECENTROIDS(X, idx, K) returns the new centroids by 
%   computing the means of the data points assigned to each centroid. It is
%   given a dataset X where each row is a single data point, a vector
%   idx of centroid assignments (i.e. each entry in range [1..K]) for each
%   example, and K, the number of centroids. You should return a matrix
%   centroids, where each row of centroids is the mean of the data points
%   assigned to it.
%

% Useful variables
[m n] = size(X);

% You need to return the following variables correctly.
centroids = zeros(K, n);


% ====================== YOUR CODE HERE ======================
% Instructions: Go over every centroid and compute mean of all points that
%               belong to it. Concretely, the row vector centroids(i, :)
%               should contain the mean of the data points assigned to
%               centroid i.
%
% Note: You can use a for-loop over the centroids to compute this.
%



for i=1:K
    sum = zeros(1,size(X,2));
    cnt = 0;
    for j=1:m
        if(idx(j,1)==i)
            sum = sum + X(j,:);
            cnt = cnt + 1;
        end
    end
    if(cnt>0)
        centroids(i,:) = sum./cnt;

    end
end

% =============================================================


end

