clear; clc;
global C D noise clusters vis cflag colors;
D = load('dataset.txt');
noise = [];
clusters = zeros(size(D,1),1);
vis = zeros(size(D,1),1);
cflag = zeros(size(D,1),1);
C = 0;
colors=zeros(125,3);
i = 1;
for r=0.1:0.15:0.9
    for g=0.1:0.15:0.9
        for b=0.1:0.15:0.9
            colors(i,:)=[r,g,b];
            i=i+1;
        end
    end
end
%%%%%%%%%%%%%%%%%%%%%%% main %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
knn = 4;
estimateParams(knn);
disp('params estimated, press enter');
pause;
eps = 1.1;
DBSCAN(eps,knn);
allIndex = plotDBSCAN();
[centroids, idx] = kMeans(C,D,allIndex);
plotKmeans(idx);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function DBSCAN(eps, MinPts)
   global D clusters noise vis C;
   disp('init');
   for i=1:size(D,1)
      P = D(i,:);
      if(vis(i,1)==1)
          %disp('h');
          continue;
      end
      vis(i,1) = 1;
      neighborPts = regionQuery(P, eps);
      %disp(size(neighborPts));
      %pause;
      if (size(neighborPts,1) < MinPts)
         noise = [noise;i];
      else
         C = C+1;
         %disp(C);
         expandCluster(i, neighborPts, C, eps, MinPts);
         disp(sum(vis==1));
         %pause;
      end;
   end;
end

function expandCluster(index, neighborPts, C, eps, MinPts)
    global clusters D vis cflag;
    %disp(C);
    clusters(index,1) = C;
    cflag(index,1)=1;
%     disp(neighborPts);
%     pause;
    for i=neighborPts'
      %disp('a');
      P = D(i,:);
      if (vis(i,1)==0)
         vis(i,1)=1;
         anotherNeighbors = regionQuery(P, eps);
         if (size(anotherNeighbors,1) >= MinPts)
            neighborPts = [neighborPts;anotherNeighbors];
         end
      end
      if (cflag(i,1)==0)
         clusters(i,1)= C;
         cflag(i,1)=1;
      end
    end
end

function neighborPts = regionQuery(P, eps)
   %return all points within P's eps-neighborhood (including P)
   neighborPts=[];
   global D;
   for i=1:size(D,1)
       dist = 0;
       for j=1:size(D,2)
           dist = dist + (P(1,j)-D(i,j)) ^ 2;
       end;
       dist = sqrt(dist);
       if(dist <= eps)
           neighborPts = [neighborPts;i];
       end;
   end
end

function allIndex = plotDBSCAN()
    global C clusters D colors noise;
    colorIndex = randperm(200,C);
    allIndex = [];
    
    figure;
    hold on;
    for i=1:C
        index = find(clusters==i);
        allIndex = [allIndex;index];
        plot(D(index,1), D(index,2), '.' ,'Color', colors(colorIndex(1,i),:));
    end
    plot(D(noise,1), D(noise,2), 'o' ,'Color', 'k');

    hold off;
    pause;
    %%%%%% call k means %%%%
end

function estimateParams(k)
   global D;
   
   kd = [];
   for i=1:size(D,1)
       d=[];
       dist = 0;
       for i2=1:size(D,1)
           for j=1:size(D,2)
               dist = dist + (D(i2,j)-D(i,j)) ^ 2;
           end;
           dist = sqrt(dist);
           d = [d;dist];
       end;
       b = sort(d);
       kd=[kd;b(k)];
   end
   b = sort(kd);
   plot(b);
end

function plotKmeans(idx)
    global C D colors noise;
    colorIndex = randperm(200,C);
    allIndex = [];
    
    figure;
    hold on;
    for i=1:C
        index = find(idx==i);
        allIndex = [allIndex;index];
        plot(D(index,1), D(index,2), '.' ,'Color', colors(colorIndex(1,i),:));
    end
    plot(D(noise,1), D(noise,2), '.' ,'Color', 'k');

    hold off;
end