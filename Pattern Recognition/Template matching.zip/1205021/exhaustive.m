v = VideoReader('input.MOV');
out = VideoWriter('outexhaustive.avi');
ref = imread('reference.jpg');
% test = imread('t.jpg');

open(out);
while hasFrame(v)
    test = readFrame(v);
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%% Exhaustive %%%%%%%%%%%%%%%%%%%%%%
    c = zeros([size(test,1),size(test,2)]);
    m = size(ref,1);
    n = size(ref,2);
    for i = 1:size(test,1)-m
        for j = 1:size(test,2)-n
            for k = 1:3
                c(i,j) = c(i,j) + corr2(test(i:i+m-1,j:j+n-1,k),ref(:,:,k));
            end
        end
    end
    [x, y] = find(c==max(c(:)));

    for i = x:x+size(ref,1)-1
        for j = [y y+size(ref,2)-1]
            test(i,j,:) = 100;
        end
    end
    for j = y:y+size(ref,2)-1
        for i = [x x+size(ref,1)-1]
            test(i,j,:) = 100;
        end
    end
    writeVideo(out, test);
end
close(out);