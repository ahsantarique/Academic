function [x, y, metric] = f(test, ref, level, p)
    if(level == 0)
        metric = 0;
        m = size(ref,1);
        n = size(ref,2);
        c = zeros(size(test));
        for i = 1:size(test,1)-m
            for j = 1:size(test,2)-n
                for k = 1:3
                    c(i,j) = c(i,j) + corr2(test(i:i+m-1,j:j+n-1,k),ref(:,:,k));
                    metric = metric + 1;
                end;
            end;
        end;
        [x, y] = find(c==max(c(:)));
        return;
    end;
    
    [x, y, metric] = f(imresize(test,0.5), imresize(ref,0.5), level-1);
    x = x*2;
    y = y*2;
end
    
    
    