v = VideoReader('input.MOV');
out = VideoWriter('outhierarchical.avi');
ref = imread('reference.jpg');
% test = imread('t.jpg');

open(out);
while hasFrame(v)
    test = readFrame(v);
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%% Hierarchical %%%%%%%%%%%%%%%%%%%
    level = 3;
    p = 30;
    [x, y, metric] = f(test, ref, level,p);
    for i = x:x+size(ref,1)-1
        for j = [y y+size(ref,2)-1]
            test(i,j,:) = 100;
        end
    end
    for j = y:y+size(ref,2)-1
        for i = [x x+size(ref,1)-1]
            test(i,j,:) = 100;
        end
    end
    writeVideo(out, test);
end
close(out);