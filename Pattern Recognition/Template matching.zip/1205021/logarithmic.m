v = VideoReader('input.MOV');
out = VideoWriter('out2dlogarithmic.avi');
ref = imread('reference.jpg');
% test = imread('t.jpg');

first = 1;

open(out);
framecount = 0;
metric = 0;
while hasFrame(v)
    test = readFrame(v);
    framecount = framecount + 1;
    %%%%%%%%%%%% 2d logarithmic %%%%%%%%%%%%%%%%%%%%%%
    c = zeros([size(test,1),size(test,2)]);
    m = size(ref,1);
    n = size(ref,2);

    if(first == 1)
        first = 0;
        tm = size(test,1);
        tn = size(test,2);
        bestx = 250;
        besty = 150;
    end
    
    p = 10;
    centercor = 0;
    for k = 1:3
        centercor = centercor + corr2(test(bestx:bestx+m-1,besty:besty+n-1,k),ref(:,:,k));
        metric = metric + 1;
    end;

    while(p~=1)
        dx = [0, 0, p, p, p, -p, -p, -p];
        dy = [p, -p, 0, p, -p, 0, p, -p];
        for i = 1:8
            x = bestx + dx(1,i);
            y = besty + dy(1,i);
            c = 0;
            if(x > 0 && x+m-1<=tm && y>0 && y+n-1 <= tn)
                for k = 1:3
                    c = c + corr2(test(x:x+m-1,y:y+n-1,k),ref(:,:,k));
                    metric = metric + 1;
                end;
            end
            if(c > centercor)
                centercor = c;
                bestx = x;
                besty = y;
            end;
        end;
        p = floor(p/2);
    end;
    x = bestx;
    y = besty;
    disp([x,y]);
    for i = x:x+size(ref,1)-1
        for j = [y y+size(ref,2)-1]
            test(i,j,:) = 100;
        end
    end
    for j = y:y+size(ref,2)-1
        for i = [x x+size(ref,1)-1]
            test(i,j,:) = 100;
        end
    end
    writeVideo(out, test);
end
close(out);
disp(metric/3/760);